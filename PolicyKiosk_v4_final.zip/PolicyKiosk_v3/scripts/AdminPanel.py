#!/usr/bin/env python3
"""
CBC Policy Kiosk - Admin Web Panel
====================================
Simple web dashboard on port 5002.
Features:
  - View all acceptance records (live)
  - Search by username / PC / IP
  - Reset a user (force re-read)
  - Reset all records
  - Export CSV
  - Statistics summary
  - Auto-refresh every 30 seconds

Run:
    python AdminPanel.py
    python AdminPanel.py --db "C:/CBCTest/policy_log.db" --port 5002

Then open browser: http://localhost:5002
"""

import os, sys, csv, io, sqlite3, datetime, argparse
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
import threading, time, json

# ─── CONFIG ──────────────────────────────────────────────────────────────────
DEFAULT_DB   = os.path.join(os.path.dirname(__file__), "policy_log.db")
DEFAULT_PORT = 5002
ADMIN_PASS   = "cbcadmin"   # change this password!
AUTO_REFRESH = 30           # seconds

# ─── DB HELPERS ──────────────────────────────────────────────────────────────
def get_conn(db_path):
    if not os.path.exists(db_path):
        return None
    return sqlite3.connect(db_path, timeout=10, check_same_thread=False)

def fetch_records(db_path, search=""):
    con = get_conn(db_path)
    if not con:
        return []
    try:
        con.row_factory = sqlite3.Row
        if search:
            s = f"%{search}%"
            rows = con.execute("""
                SELECT * FROM policy_acceptance
                WHERE username LIKE ? OR pc_name LIKE ? OR ip_address LIKE ? OR domain LIKE ?
                ORDER BY end_time DESC
            """, (s,s,s,s)).fetchall()
        else:
            rows = con.execute(
                "SELECT * FROM policy_acceptance ORDER BY end_time DESC"
            ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []
    finally:
        con.close()

def get_stats(db_path):
    con = get_conn(db_path)
    if not con:
        return {}
    try:
        con.row_factory = sqlite3.Row
        total   = con.execute("SELECT COUNT(*) FROM policy_acceptance").fetchone()[0]
        today   = con.execute("SELECT COUNT(*) FROM policy_acceptance WHERE DATE(end_time)=DATE('now')").fetchone()[0]
        avg_dur = con.execute("SELECT AVG(read_duration_sec) FROM policy_acceptance").fetchone()[0] or 0
        latest  = con.execute("SELECT end_time FROM policy_acceptance ORDER BY end_time DESC LIMIT 1").fetchone()
        versions = con.execute("SELECT policy_version, COUNT(*) as cnt FROM policy_acceptance GROUP BY policy_version").fetchall()
        return {
            "total": total, "today": today,
            "avg_duration": int(avg_dur),
            "latest": latest[0] if latest else "N/A",
            "versions": [dict(v) for v in versions]
        }
    except Exception:
        return {}
    finally:
        con.close()

def reset_user(db_path, username, pc_name=""):
    con = get_conn(db_path)
    if not con: return 0
    try:
        if pc_name:
            cur = con.execute("DELETE FROM policy_acceptance WHERE username=? AND pc_name=?", (username, pc_name))
        else:
            cur = con.execute("DELETE FROM policy_acceptance WHERE username=?", (username,))
        con.commit()
        # Also delete local flag on this machine (best effort)
        return cur.rowcount
    finally:
        con.close()

def reset_all(db_path):
    con = get_conn(db_path)
    if not con: return 0
    try:
        cur = con.execute("DELETE FROM policy_acceptance")
        con.commit()
        return cur.rowcount
    finally:
        con.close()

def export_csv(db_path):
    rows = fetch_records(db_path)
    out  = io.StringIO()
    w    = csv.writer(out)
    w.writerow(["ID","Username","PC Name","Domain","IP Address",
                "Start Time","End Time","Read Duration (sec)","Policy Version","Accepted"])
    for r in rows:
        dur = f"{r['read_duration_sec']//60}m {r['read_duration_sec']%60}s"
        w.writerow([r["id"],r["username"],r["pc_name"],r["domain"],
                    r["ip_address"],r["start_time"],r["end_time"],
                    dur, r["policy_version"],r["accepted"]])
    return out.getvalue()

# ─── HTML TEMPLATE ───────────────────────────────────────────────────────────
def render_page(db_path, search="", message="", msg_type="success"):
    records = fetch_records(db_path, search)
    stats   = get_stats(db_path)
    db_ok   = os.path.exists(db_path)

    # Build table rows
    rows_html = ""
    for r in records:
        dur = f"{r['read_duration_sec']//60}m {r['read_duration_sec']%60}s"
        rows_html += f"""
        <tr>
            <td>{r['id']}</td>
            <td><b>{r['username']}</b></td>
            <td>{r['pc_name']}</td>
            <td>{r['domain'] or ''}</td>
            <td>{r['ip_address'] or ''}</td>
            <td>{r['start_time']}</td>
            <td>{r['end_time']}</td>
            <td><span class="dur">{dur}</span></td>
            <td><span class="ver">{r['policy_version']}</span></td>
            <td>
                <form method="POST" action="/reset_user" style="display:inline"
                      onsubmit="return confirm('Reset {r['username']} on {r['pc_name']}?')">
                    <input type="hidden" name="username" value="{r['username']}">
                    <input type="hidden" name="pc_name"  value="{r['pc_name']}">
                    <button class="btn-reset" type="submit">Reset</button>
                </form>
            </td>
        </tr>"""

    # Version badges
    ver_badges = ""
    for v in stats.get("versions", []):
        ver_badges += f'<span class="badge">{v["policy_version"]}: {v["cnt"]}</span> '

    msg_html = ""
    if message:
        msg_html = f'<div class="msg {msg_type}">{message}</div>'

    avg = stats.get("avg_duration", 0)
    avg_str = f"{avg//60}m {avg%60}s"

    return f"""<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="{AUTO_REFRESH}">
<title>CBC Policy Kiosk – Admin Panel</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:'Segoe UI',sans-serif;background:#0a1628;color:#e8e8e8;min-height:100vh}}
  header{{background:#0d1f3c;border-bottom:3px solid #c8960c;padding:16px 30px;display:flex;align-items:center;justify-content:space-between}}
  header h1{{color:#c8960c;font-size:1.3em}}
  header .sub{{color:#6688aa;font-size:0.85em;margin-top:4px}}
  .db-path{{color:#445566;font-size:0.8em;margin-top:2px}}
  .refresh{{color:#445566;font-size:0.8em}}
  .container{{padding:24px 30px}}
  .stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;margin-bottom:24px}}
  .stat-card{{background:#112240;border:1px solid #1a2e4a;border-radius:8px;padding:18px;text-align:center}}
  .stat-card .num{{font-size:2em;font-weight:bold;color:#c8960c}}
  .stat-card .lbl{{color:#6688aa;font-size:0.85em;margin-top:4px}}
  .stat-card.green .num{{color:#4cde7a}}
  .stat-card.blue  .num{{color:#4ab4ff}}
  .controls{{display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap;align-items:center}}
  .controls form{{display:flex;gap:8px;flex-wrap:wrap}}
  input[type=text]{{background:#112240;border:1px solid #1a2e4a;color:#e8e8e8;padding:8px 14px;border-radius:6px;font-size:0.9em;width:240px}}
  input[type=text]:focus{{outline:none;border-color:#c8960c}}
  .btn{{padding:8px 18px;border:none;border-radius:6px;cursor:pointer;font-size:0.9em;font-weight:600;text-decoration:none;display:inline-block}}
  .btn-search{{background:#1a4a7a;color:#fff}}
  .btn-search:hover{{background:#1e5590}}
  .btn-export{{background:#1a5c2a;color:#fff}}
  .btn-export:hover{{background:#22773a}}
  .btn-danger{{background:#5c1a1a;color:#fff}}
  .btn-danger:hover{{background:#7a2222}}
  .btn-clear{{background:#1a2e4a;color:#aaa}}
  .btn-clear:hover{{background:#243d63;color:#fff}}
  .btn-reset{{background:#3a1a1a;color:#ff8888;border:1px solid #5c2a2a;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:0.8em}}
  .btn-reset:hover{{background:#5c2222;color:#ffaaaa}}
  table{{width:100%;border-collapse:collapse;font-size:0.88em}}
  th{{background:#112240;color:#c8960c;padding:10px 12px;text-align:left;position:sticky;top:0;z-index:1;border-bottom:2px solid #1a2e4a}}
  td{{padding:9px 12px;border-bottom:1px solid #0f1d35;white-space:nowrap}}
  tr:hover td{{background:#112240}}
  .table-wrap{{overflow-x:auto;border-radius:8px;border:1px solid #1a2e4a}}
  .dur{{color:#4ab4ff;font-weight:600}}
  .ver{{background:#1a2e4a;color:#c8960c;padding:2px 8px;border-radius:10px;font-size:0.8em}}
  .badge{{background:#1a2e4a;color:#c8960c;padding:3px 10px;border-radius:10px;font-size:0.82em;margin-right:6px}}
  .msg{{padding:12px 18px;border-radius:6px;margin-bottom:18px;font-weight:600}}
  .msg.success{{background:#0d2a14;color:#4cde7a;border:1px solid #1a5c2a}}
  .msg.error{{background:#2a0d0d;color:#ff8888;border:1px solid #5c1a1a}}
  .no-db{{background:#2a1a0d;color:#ffaa44;border:1px solid #5c3a1a;padding:16px;border-radius:8px;margin-bottom:18px}}
  .total-row{{color:#6688aa;font-size:0.85em;margin-top:10px}}
  footer{{color:#2a3a4a;font-size:0.78em;padding:20px 30px;border-top:1px solid #0f1d35;margin-top:30px}}
  .ver-row{{margin-bottom:16px}}
</style>
</head><body>

<header>
  <div>
    <h1>🏛 CBC Policy Kiosk – Admin Panel</h1>
    <div class="sub">Commercial Bank of Ceylon PLC – IT Operations</div>
    <div class="db-path">DB: {db_path}</div>
  </div>
  <div class="refresh">Auto-refresh: {AUTO_REFRESH}s &nbsp;|&nbsp; {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
</header>

<div class="container">

  {msg_html}

  {'<div class="no-db">⚠️ Database file not found: ' + db_path + '<br>The DB will be created automatically after the first user accepts the policy.</div>' if not db_ok else ''}

  <!-- Stats -->
  <div class="stats">
    <div class="stat-card">
      <div class="num">{stats.get('total',0)}</div>
      <div class="lbl">Total Accepted</div>
    </div>
    <div class="stat-card green">
      <div class="num">{stats.get('today',0)}</div>
      <div class="lbl">Accepted Today</div>
    </div>
    <div class="stat-card blue">
      <div class="num">{avg_str}</div>
      <div class="lbl">Avg Read Time</div>
    </div>
    <div class="stat-card">
      <div class="num" style="font-size:0.9em">{stats.get('latest','N/A')}</div>
      <div class="lbl">Latest Acceptance</div>
    </div>
  </div>

  <div class="ver-row">{ver_badges}</div>

  <!-- Controls -->
  <div class="controls">
    <form method="GET" action="/">
      <input type="text" name="search" placeholder="Search username / PC / IP..."
             value="{search}">
      <button type="submit" class="btn btn-search">🔍 Search</button>
      <a href="/" class="btn btn-clear">✕ Clear</a>
    </form>
    <a href="/export_csv" class="btn btn-export">⬇ Export CSV</a>
    <form method="POST" action="/reset_all"
          onsubmit="return confirm('DELETE ALL records? This cannot be undone!')">
      <button type="submit" class="btn btn-danger">🗑 Reset All Records</button>
    </form>
  </div>

  <!-- Table -->
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Username</th><th>PC Name</th><th>Domain</th>
          <th>IP Address</th><th>Start Time</th><th>End Time</th>
          <th>Read Duration</th><th>Version</th><th>Action</th>
        </tr>
      </thead>
      <tbody>
        {rows_html if rows_html else '<tr><td colspan="10" style="text-align:center;color:#445566;padding:30px">No records found.</td></tr>'}
      </tbody>
    </table>
  </div>
  <div class="total-row">Showing {len(records)} record(s){' matching "' + search + '"' if search else ''}</div>

</div>

<footer>
  CBC Policy Kiosk Admin Panel &nbsp;|&nbsp;
  IT Operations – Network &amp; Infra Security &nbsp;|&nbsp;
  Commercial Bank of Ceylon PLC &nbsp;|&nbsp;
  Port {DEFAULT_PORT}
</footer>
</body></html>"""

# ─── HTTP HANDLER ─────────────────────────────────────────────────────────────
class AdminHandler(BaseHTTPRequestHandler):
    db_path = DEFAULT_DB

    def log_message(self, format, *args):
        pass  # suppress default access log

    def send_html(self, html, code=200):
        data = html.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", len(data))
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, location):
        self.send_response(302)
        self.send_header("Location", location)
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        if parsed.path == "/":
            search = params.get("search", [""])[0]
            msg    = params.get("msg",    [""])[0]
            mtype  = params.get("mtype",  ["success"])[0]
            html   = render_page(self.db_path, search, msg, mtype)
            self.send_html(html)

        elif parsed.path == "/export_csv":
            data = export_csv(self.db_path).encode("utf-8")
            fname = f"PolicyAcceptance_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.csv"
            self.send_response(200)
            self.send_header("Content-Type", "text/csv")
            self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
            self.send_header("Content-Length", len(data))
            self.end_headers()
            self.wfile.write(data)

        elif parsed.path == "/api/stats":
            data = json.dumps(get_stats(self.db_path)).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", len(data))
            self.end_headers()
            self.wfile.write(data)

        else:
            self.send_html("<h1>404 Not Found</h1>", 404)

    def do_POST(self):
        length  = int(self.headers.get("Content-Length", 0))
        body    = self.rfile.read(length).decode("utf-8")
        params  = parse_qs(body)

        if self.path == "/reset_user":
            username = params.get("username", [""])[0]
            pc_name  = params.get("pc_name",  [""])[0]
            count    = reset_user(self.db_path, username, pc_name)
            # Also delete local flag file on server if accessible
            msg   = f"Reset {count} record(s) for user '{username}' on '{pc_name}'. They will see the kiosk on next logon."
            mtype = "success" if count > 0 else "error"
            self.redirect(f"/?msg={quote(msg)}&mtype={mtype}")

        elif self.path == "/reset_all":
            count = reset_all(self.db_path)
            msg   = f"All {count} record(s) deleted. All users will see the kiosk on next logon."
            self.redirect(f"/?msg={quote(msg)}&mtype=success")

        else:
            self.send_html("<h1>404</h1>", 404)

# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(description="CBC Policy Kiosk Admin Web Panel")
    ap.add_argument("--db",   default=DEFAULT_DB,   help="Path to policy_log.db")
    ap.add_argument("--port", default=DEFAULT_PORT,  type=int, help="Port (default 5002)")
    args = ap.parse_args()

    AdminHandler.db_path = os.path.abspath(args.db)

    server = HTTPServer(("0.0.0.0", args.port), AdminHandler)
    print("=" * 60)
    print("  CBC Policy Kiosk – Admin Panel")
    print("=" * 60)
    print(f"  URL      : http://localhost:{args.port}")
    print(f"  Database : {AdminHandler.db_path}")
    print(f"  Refresh  : every {AUTO_REFRESH} seconds")
    print("  Press Ctrl+C to stop")
    print("=" * 60)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nAdmin panel stopped.")

if __name__ == "__main__":
    main()
