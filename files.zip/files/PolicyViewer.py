#!/usr/bin/env python3
"""
Commercial Bank of Ceylon PLC
Policy Acceptance Kiosk Viewer
================================
Full-screen PDF viewer with:
  - Page-by-page navigation (Next / Previous)
  - Accept button visible ONLY on last page
  - All system hotkeys blocked (Alt+F4, Win, Alt+Tab, Ctrl+Esc, etc.)
  - Exits with code 0 on acceptance, code 1 on close/escape attempt
  - Creates an acceptance flag file for the PowerShell parent script

Usage (called by PolicyLogon.ps1):
    python PolicyViewer.py --pdf <path> --user <username> --pc <pcname> --accept-flag <flagfile>

Dependencies:
    pip install PyMuPDF Pillow
"""

import sys
import os
import argparse
import datetime
import threading
import tkinter as tk
from tkinter import ttk, font as tkfont
from PIL import Image, ImageTk

# Try importing PyMuPDF (fitz)
try:
    import fitz  # PyMuPDF
except ImportError:
    print("ERROR: PyMuPDF not installed. Run: pip install PyMuPDF")
    sys.exit(2)

# Windows-only keyboard hook
WINDOWS = sys.platform == "win32"
if WINDOWS:
    import ctypes
    import ctypes.wintypes

# ─── CONSTANTS ────────────────────────────────────────────────────────────────
APP_TITLE   = "Commercial Bank of Ceylon – Policy Acceptance"
BG_COLOR    = "#0a1628"       # deep navy
ACCENT      = "#c8960c"       # gold
BTN_COLOR   = "#1a2e4a"
BTN_HOVER   = "#243d63"
TEXT_COLOR  = "#e8e8e8"
NAV_HEIGHT  = 80
HEADER_H    = 50
DPI_SCALE   = 1.5             # render at 1.5x for sharpness

# ─── KEYBOARD HOOK (Windows) ──────────────────────────────────────────────────
if WINDOWS:
    WH_KEYBOARD_LL = 13
    WM_KEYDOWN     = 0x0100
    WM_SYSKEYDOWN  = 0x0104

    BLOCKED_KEYS = {
        0x09,   # Tab  (Alt+Tab)
        0x1B,   # Escape
        0x5B,   # Left Windows
        0x5C,   # Right Windows
        0x5D,   # Apps/Menu
        0x79,   # F10
        0x7A,   # F11
        0x7B,   # F12
        0x2C,   # PrintScreen
    }

    LowLevelKeyboardProc = ctypes.WINFUNCTYPE(
        ctypes.c_int, ctypes.c_int, ctypes.wintypes.WPARAM, ctypes.wintypes.LPARAM
    )

    _hook_id   = None
    _hook_proc = None   # keep reference to prevent GC

    def _keyboard_hook_proc(nCode, wParam, lParam):
        if nCode >= 0 and wParam in (WM_KEYDOWN, WM_SYSKEYDOWN):
            vk_code = ctypes.cast(lParam, ctypes.POINTER(ctypes.c_ulong))[0]
            if vk_code in BLOCKED_KEYS:
                return 1   # block the key
        return ctypes.windll.user32.CallNextHookEx(_hook_id, nCode, wParam, lParam)

    def install_keyboard_hook():
        global _hook_id, _hook_proc
        _hook_proc = LowLevelKeyboardProc(_keyboard_hook_proc)
        _hook_id = ctypes.windll.user32.SetWindowsHookExW(
            WH_KEYBOARD_LL, _hook_proc,
            ctypes.windll.kernel32.GetModuleHandleW(None), 0
        )

    def remove_keyboard_hook():
        global _hook_id
        if _hook_id:
            ctypes.windll.user32.UnhookWindowsHookEx(_hook_id)
            _hook_id = None

    def run_message_pump():
        """Run the Windows message loop for the hook in a background thread."""
        msg = ctypes.wintypes.MSG()
        while ctypes.windll.user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
            ctypes.windll.user32.TranslateMessage(ctypes.byref(msg))
            ctypes.windll.user32.DispatchMessageW(ctypes.byref(msg))

else:
    def install_keyboard_hook(): pass
    def remove_keyboard_hook(): pass
    def run_message_pump(): pass


# ─── PDF LOADER ───────────────────────────────────────────────────────────────
class PolicyPDF:
    def __init__(self, path):
        self.doc    = fitz.open(path)
        self.count  = len(self.doc)
        self._cache = {}

    def render_page(self, page_num: int, width: int, height: int) -> ImageTk.PhotoImage:
        """Render a PDF page scaled to fit the given width/height."""
        cache_key = (page_num, width, height)
        if cache_key in self._cache:
            return self._cache[cache_key]

        page   = self.doc[page_num]
        pr     = page.rect
        width  = max(width, 100)
        height = max(height, 100)
        scale  = min(width / pr.width, height / pr.height) * DPI_SCALE
        matrix = fitz.Matrix(scale, scale)
        pix    = page.get_pixmap(matrix=matrix, alpha=False)
        img    = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        # Resize to exact fit
        img.thumbnail((width, height), Image.LANCZOS)
        photo = ImageTk.PhotoImage(img)
        self._cache[cache_key] = photo
        return photo

    def close(self):
        self.doc.close()


# ─── MAIN VIEWER APPLICATION ──────────────────────────────────────────────────
class PolicyViewer:
    def __init__(self, pdf_path: str, username: str, pc_name: str, accept_flag: str):
        self.pdf_path    = pdf_path
        self.username    = username
        self.pc_name     = pc_name
        self.accept_flag = accept_flag
        self.current     = 0
        self.accepted    = False

        self._build_window()
        self._load_pdf()
        self._build_ui()
        # Delay first render so window has real dimensions
        self.root.after(150, lambda: self._show_page(0))

    # ── WINDOW SETUP ──────────────────────────────────────────────────────────
    def _build_window(self):
        self.root = tk.Tk()
        self.root.title(APP_TITLE)
        self.root.configure(bg=BG_COLOR)

        # Full screen
        self.root.attributes("-fullscreen", True)
        self.root.attributes("-topmost", True)
        self.root.focus_force()

        # Grab all input to prevent alt-tab/win key via Tk
        self.root.grab_set_global()

        # Override close button
        self.root.protocol("WM_DELETE_WINDOW", self._on_close_attempt)

        # Bind Escape to nothing (blocked by hook, double-safe)
        self.root.bind("<Escape>",      lambda e: "break")
        self.root.bind("<Alt-F4>",      lambda e: "break")
        self.root.bind("<Alt-Tab>",     lambda e: "break")
        self.root.bind("<Super_L>",     lambda e: "break")
        self.root.bind("<Super_R>",     lambda e: "break")
        self.root.bind("<Control-Alt-Delete>", lambda e: "break")

        # Get screen dimensions
        self.screen_w = self.root.winfo_screenwidth()
        self.screen_h = self.root.winfo_screenheight()

    def _on_close_attempt(self):
        pass   # Do nothing — cannot close until accepted

    # ── PDF LOADING ───────────────────────────────────────────────────────────
    def _load_pdf(self):
        self.pdf = PolicyPDF(self.pdf_path)

    # ── UI CONSTRUCTION ───────────────────────────────────────────────────────
    def _build_ui(self):
        sw, sh = self.screen_w, self.screen_h

        # ── Header bar ──────────────────────────────────────────────────────
        self.header = tk.Frame(self.root, bg=BG_COLOR, height=HEADER_H)
        self.header.pack(fill=tk.X, side=tk.TOP)
        self.header.pack_propagate(False)

        # Logo / bank name
        tk.Label(
            self.header,
            text="  🏛  Commercial Bank of Ceylon PLC  –  Employee Policy Document",
            bg=BG_COLOR, fg=ACCENT,
            font=("Georgia", 13, "bold"),
            anchor="w"
        ).pack(side=tk.LEFT, padx=16, pady=8)

        # Page counter (right side)
        self.lbl_page = tk.Label(
            self.header, bg=BG_COLOR, fg=TEXT_COLOR,
            font=("Consolas", 11), anchor="e"
        )
        self.lbl_page.pack(side=tk.RIGHT, padx=16)

        # Gold separator
        tk.Frame(self.root, bg=ACCENT, height=2).pack(fill=tk.X)

        # ── PDF canvas area ──────────────────────────────────────────────────
        canvas_h = sh - HEADER_H - 2 - NAV_HEIGHT
        self.canvas_frame = tk.Frame(self.root, bg="#111c2d", width=sw, height=canvas_h)
        self.canvas_frame.pack(fill=tk.BOTH, expand=True)
        self.canvas_frame.pack_propagate(False)

        self.canvas = tk.Canvas(
            self.canvas_frame, bg="#111c2d",
            highlightthickness=0, cursor="arrow"
        )
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self._img_ref = None   # prevent GC

        # ── Navigation bar ───────────────────────────────────────────────────
        tk.Frame(self.root, bg=ACCENT, height=2).pack(fill=tk.X)

        self.nav_bar = tk.Frame(self.root, bg=BG_COLOR, height=NAV_HEIGHT)
        self.nav_bar.pack(fill=tk.X, side=tk.BOTTOM)
        self.nav_bar.pack_propagate(False)

        btn_style = {
            "bg": BTN_COLOR, "fg": TEXT_COLOR,
            "activebackground": BTN_HOVER, "activeforeground": ACCENT,
            "relief": tk.FLAT, "bd": 0,
            "font": ("Consolas", 11, "bold"),
            "cursor": "hand2", "padx": 20, "pady": 8
        }

        # Previous button
        self.btn_prev = tk.Button(
            self.nav_bar, text="◀  Previous Page",
            command=self._prev_page, **btn_style
        )
        self.btn_prev.pack(side=tk.LEFT, padx=(20, 8), pady=12)

        # Progress bar (centre)
        self.progress_var = tk.DoubleVar()
        prog_frame = tk.Frame(self.nav_bar, bg=BG_COLOR)
        prog_frame.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=20)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Gold.Horizontal.TProgressbar",
            troughcolor="#1a2e4a", background=ACCENT,
            thickness=10, borderwidth=0
        )
        self.progress = ttk.Progressbar(
            prog_frame, variable=self.progress_var,
            style="Gold.Horizontal.TProgressbar",
            maximum=100, length=300
        )
        self.progress.pack(fill=tk.X, pady=(22, 6))

        self.lbl_progress = tk.Label(
            prog_frame, bg=BG_COLOR, fg="#8899aa",
            font=("Consolas", 9)
        )
        self.lbl_progress.pack()

        # Next button
        self.btn_next = tk.Button(
            self.nav_bar, text="Next Page  ▶",
            command=self._next_page, **btn_style
        )
        self.btn_next.pack(side=tk.RIGHT, padx=(8, 8), pady=12)

        # Accept button (hidden until last page)
        self.btn_accept = tk.Button(
            self.nav_bar,
            text="✔  I Have Read and Accept This Policy",
            command=self._on_accept,
            bg="#1a5c2a", fg="#ffffff",
            activebackground="#22773a", activeforeground="#ffffff",
            relief=tk.FLAT, bd=0,
            font=("Georgia", 12, "bold"),
            cursor="hand2", padx=28, pady=8
        )
        # btn_accept packed on last page only

        # Bind mouse wheel scroll
        self.root.bind("<MouseWheel>",      self._on_mousewheel)
        self.root.bind("<Button-4>",        lambda e: self._prev_page())
        self.root.bind("<Button-5>",        lambda e: self._next_page())
        self.root.bind("<Right>",           lambda e: self._next_page())
        self.root.bind("<Left>",            lambda e: self._prev_page())

    # ── PAGE NAVIGATION ───────────────────────────────────────────────────────
    def _show_page(self, page_num: int):
        self.current = max(0, min(page_num, self.pdf.count - 1))
        total = self.pdf.count

        # Update header counter
        self.lbl_page.config(text=f"Page {self.current + 1} of {total}  ")

        # Render PDF page — wait until canvas has real dimensions
        self.root.update_idletasks()
        self.root.update()
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw < 50:
            cw = self.screen_w - 40
        if ch < 50:
            ch = self.screen_h - HEADER_H - 2 - NAV_HEIGHT - 20

        photo = self.pdf.render_page(self.current, max(cw - 20, 100), max(ch - 10, 100))
        self._img_ref = photo

        self.canvas.delete("all")
        self.canvas.create_image(cw // 2, ch // 2, image=photo, anchor=tk.CENTER)

        # Update progress bar
        pct = ((self.current + 1) / total) * 100
        self.progress_var.set(pct)
        self.lbl_progress.config(
            text=f"Reading progress: {self.current + 1}/{total} pages  ({int(pct)}%)"
        )

        # Update buttons
        self.btn_prev.config(state=tk.NORMAL if self.current > 0 else tk.DISABLED)
        self.btn_next.config(state=tk.NORMAL if self.current < total - 1 else tk.DISABLED)

        # Show / hide Accept button
        if self.current == total - 1:
            self.btn_next.pack_forget()
            self.btn_accept.pack(side=tk.RIGHT, padx=(8, 20), pady=12)
            # Pulse animation on accept button
            self._pulse_accept_btn(True)
        else:
            self.btn_accept.pack_forget()
            self.btn_next.pack(side=tk.RIGHT, padx=(8, 8), pady=12)
            self._pulse_accept_btn(False)

    def _next_page(self):
        if self.current < self.pdf.count - 1:
            self._show_page(self.current + 1)

    def _prev_page(self):
        if self.current > 0:
            self._show_page(self.current - 1)

    def _on_mousewheel(self, event):
        if event.delta > 0 or event.num == 4:
            self._prev_page()
        else:
            self._next_page()

    # ── ACCEPT BUTTON PULSE ───────────────────────────────────────────────────
    _pulse_job = None
    _pulse_state = False

    def _pulse_accept_btn(self, start: bool):
        if self._pulse_job:
            self.root.after_cancel(self._pulse_job)
            self._pulse_job = None
        if start:
            self._do_pulse()

    def _do_pulse(self):
        self._pulse_state = not self._pulse_state
        color = "#22773a" if self._pulse_state else "#1a5c2a"
        self.btn_accept.config(bg=color)
        self._pulse_job = self.root.after(700, self._do_pulse)

    # ── ACCEPT ACTION ─────────────────────────────────────────────────────────
    def _on_accept(self):
        # Write acceptance flag file
        try:
            with open(self.accept_flag, "w") as f:
                f.write(f"{self.username},{self.pc_name},{datetime.datetime.now().isoformat()}")
        except Exception as e:
            print(f"WARNING: Could not write accept flag: {e}")

        self.accepted = True

        # Show thank-you overlay
        overlay = tk.Frame(self.root, bg="#0d2a14")
        overlay.place(relx=0.5, rely=0.5, anchor=tk.CENTER,
                      width=540, height=200)

        tk.Label(
            overlay,
            text="✔  Policy Accepted",
            bg="#0d2a14", fg="#4cde7a",
            font=("Georgia", 22, "bold")
        ).pack(pady=(30, 8))

        tk.Label(
            overlay,
            text=f"Thank you, {self.username}.\nYour acceptance has been recorded.",
            bg="#0d2a14", fg=TEXT_COLOR,
            font=("Consolas", 11),
            justify=tk.CENTER
        ).pack()

        self.root.after(2500, self._finish)

    def _finish(self):
        remove_keyboard_hook()
        self.pdf.close()
        self.root.grab_release()
        self.root.destroy()

    # ── RUN ───────────────────────────────────────────────────────────────────
    def run(self):
        # Install Windows keyboard hook in background thread
        install_keyboard_hook()
        t = threading.Thread(target=run_message_pump, daemon=True)
        t.start()

        self.root.mainloop()
        return 0 if self.accepted else 1


# ─── ENTRY POINT ─────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="CBC Policy Acceptance Kiosk Viewer")
    parser.add_argument("--pdf",         required=True,  help="Path to policy PDF")
    parser.add_argument("--user",        default=os.environ.get("USERNAME", "unknown"))
    parser.add_argument("--pc",          default=os.environ.get("COMPUTERNAME", "unknown"))
    parser.add_argument("--accept-flag", default=r"C:\Temp\cbc_policy_accepted.tmp",
                        help="File path to create on acceptance (read by PowerShell)")
    args = parser.parse_args()

    if not os.path.isfile(args.pdf):
        print(f"ERROR: PDF not found: {args.pdf}")
        sys.exit(2)

    viewer = PolicyViewer(
        pdf_path    = args.pdf,
        username    = args.user,
        pc_name     = args.pc,
        accept_flag = args.accept_flag
    )
    exit_code = viewer.run()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
