# CBC Policy Kiosk – Deployment Guide
**Commercial Bank of Ceylon PLC – IT Operations**

---

## Files in This Package

| File | Purpose |
|---|---|
| `PolicyLogon.ps1` | GPO logon script (main entry point) |
| `PolicyViewer.py` | Python kiosk viewer (called by PS1) |
| `PolicyReport.ps1` | Admin tool to view/export acceptance logs |
| `CompanyPolicy.pdf` | ← **YOU MUST ADD THIS** (your 16-page PDF) |

---

## Quick Deploy Steps

### 1. Place Files on Network Share
Copy all files to a share accessible by all domain PCs, e.g.:
```
\\CBC-FS01\SYSVOL\CBCPolicies\
```
Ensure **Domain Computers** (or **Domain Users**) have **Read** permission.

### 2. Install Python on All PCs
- Download Python 3.10+ from python.org
- Install with **"Add to PATH"** checked
- Deploy via SCCM/Intune if available, or include in base image

Alternatively, use a **bundled PyInstaller .exe** (see Step 6 below).

### 3. Configure GPO
1. Open **Group Policy Management Console**
2. Create or edit a GPO linked to the OU containing your employee computers
3. Go to: `User Configuration → Windows Settings → Scripts → Logon`
4. Add script: `\\CBC-FS01\SYSVOL\CBCPolicies\PolicyLogon.ps1`

### 4. Allow PowerShell Scripts (if needed)
If PowerShell execution policy blocks scripts, add this to the same GPO:
- `Computer Configuration → Administrative Templates → Windows Components → Windows PowerShell`
- Set **"Turn on Script Execution"** → `Allow local scripts and remote signed scripts`

Or run once: `Set-ExecutionPolicy RemoteSigned -Scope LocalMachine`

### 5. Test
Log on as a test user on a domain PC. The kiosk should:
1. Black out secondary monitor (if dual-monitor)
2. Open full-screen PDF viewer
3. Allow page navigation but NOT close
4. Show **Accept** button only on page 16
5. On accept: log to CSV, restore monitors, proceed to desktop
6. On second logon: skip kiosk entirely

---

## Dual Monitor Behaviour

| State | What Happens |
|---|---|
| Single monitor | Normal full-screen kiosk |
| Dual monitors, not yet accepted | Secondary goes BLACK; kiosk runs on primary |
| User clicks Accept | Both monitors restored (extended desktop) |
| User already accepted | Both monitors work normally from logon |

---

## Acceptance Log (CSV)

Stored at: `\\CBC-FS01\SYSVOL\CBCPolicies\accepted_users.csv`
Also cached locally at: `%LOCALAPPDATA%\CBCPolicy\accepted_users.csv`

Columns: `Username, PCName, Domain, IPAddress, Timestamp`

### Admin Reports
```powershell
# View in terminal
.\PolicyReport.ps1

# Export HTML report
.\PolicyReport.ps1 -Export

# Force a user to re-read (e.g. policy updated)
.\PolicyReport.ps1 -Reset "jdoe"

# New policy version — reset everyone
.\PolicyReport.ps1 -ResetAll
```

---

## Optional: Bundle Python as .exe (No Python Install Required)

If installing Python on all PCs is not feasible:
```bash
pip install pyinstaller
pyinstaller --onefile --noconsole PolicyViewer.py
```
Place `PolicyViewer.exe` in the share folder and update `PolicyLogon.ps1`:
```powershell
$PythonExe = ""          # leave empty
$ViewerExe = Join-Path $ScriptRoot "PolicyViewer.exe"
# Replace the Start-Process line with:
$proc = Start-Process -FilePath $ViewerExe -ArgumentList $viewerArgs -PassThru -WindowStyle Normal
```

---

## Blocked Keys During Kiosk

The viewer blocks:
- `Escape`
- `Alt+F4`
- `Alt+Tab`
- `Windows key (L/R)`
- `F11 / F12`
- `PrintScreen`
- `Ctrl+Esc`
- Task Manager (`Ctrl+Shift+Esc`) via registry

---

## Support
IT Operations – IT Network & Infra. Security  
Commercial Bank of Ceylon PLC
