#Requires -Version 5.1
<#
.SYNOPSIS
    Commercial Bank of Ceylon - Policy Acceptance Kiosk (GPO Logon Script)
.DESCRIPTION
    Runs at user logon via GPO. Displays a 16-page policy PDF in full-screen kiosk
    mode. Disables PC functions until the user accepts. Logs acceptance to CSV.
    On dual-monitor setups: blacks out secondary monitor until acceptance, then
    restores it.
.NOTES
    Deploy via: Computer Configuration > Windows Settings > Scripts > Logon
    OR: User Configuration > Windows Settings > Scripts > Logon
    
    REQUIRED FILES (place all in same network share folder):
        PolicyLogon.ps1       <- this script
        PolicyViewer.py       <- Python kiosk viewer
        CompanyPolicy.pdf     <- the 16-page PDF
        accepted_users.csv    <- auto-created on first run
#>

# ─── CONFIGURATION ────────────────────────────────────────────────────────────
$ScriptRoot    = $PSScriptRoot                          # folder where this script lives
$PolicyPDF     = Join-Path $ScriptRoot "CompanyPolicy.pdf"
$ViewerScript  = Join-Path $ScriptRoot "PolicyViewer.py"
$LogCSV        = Join-Path $ScriptRoot "accepted_users.csv"
$PythonExe     = "python"                              # or full path e.g. "C:\Python312\python.exe"
$LocalLogCSV   = "$env:LOCALAPPDATA\CBCPolicy\accepted_users.csv"  # local copy for offline check
# ──────────────────────────────────────────────────────────────────────────────

# ─── HELPER: Write to Event Log ───────────────────────────────────────────────
function Write-PolicyLog {
    param([string]$Message, [string]$Level = "Information")
    try {
        if (-not [System.Diagnostics.EventLog]::SourceExists("CBCPolicyKiosk")) {
            New-EventLog -LogName Application -Source "CBCPolicyKiosk" -ErrorAction SilentlyContinue
        }
        $entryType = [System.Diagnostics.EventLogEntryType]::$Level
        Write-EventLog -LogName Application -Source "CBCPolicyKiosk" -EventId 1000 `
                       -EntryType $entryType -Message $Message -ErrorAction SilentlyContinue
    } catch {}
    Write-Host "[$Level] $Message"
}

# ─── CHECK: Already accepted? ─────────────────────────────────────────────────
function Test-AlreadyAccepted {
    $username  = $env:USERNAME
    $pcname    = $env:COMPUTERNAME

    # Check local cache first (works offline)
    if (Test-Path $LocalLogCSV) {
        $rows = Import-Csv $LocalLogCSV
        if ($rows | Where-Object { $_.Username -eq $username -and $_.PCName -eq $pcname }) {
            Write-PolicyLog "User '$username' on '$pcname' already accepted. Skipping kiosk."
            return $true
        }
    }

    # Also check network share
    if (Test-Path $LogCSV) {
        $rows = Import-Csv $LogCSV
        if ($rows | Where-Object { $_.Username -eq $username -and $_.PCName -eq $pcname }) {
            # Update local cache
            Save-LocalAcceptance -Username $username -PCName $pcname
            Write-PolicyLog "User '$username' on '$pcname' already accepted (network). Skipping."
            return $true
        }
    }
    return $false
}

# ─── SAVE: Write acceptance record ────────────────────────────────────────────
function Save-LocalAcceptance {
    param([string]$Username, [string]$PCName)
    $localDir = Split-Path $LocalLogCSV
    if (-not (Test-Path $localDir)) { New-Item -ItemType Directory -Path $localDir -Force | Out-Null }
    $record = [PSCustomObject]@{
        Username  = $Username
        PCName    = $PCName
        Timestamp = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        Domain    = $env:USERDOMAIN
        IPAddress = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.IPAddress -notlike '127.*'} | Select-Object -First 1 -ExpandProperty IPAddress)
    }
    # Append or create
    if (Test-Path $LocalLogCSV) {
        $record | Export-Csv $LocalLogCSV -Append -NoTypeInformation
    } else {
        $record | Export-Csv $LocalLogCSV -NoTypeInformation
    }
}

function Save-NetworkAcceptance {
    param([string]$Username, [string]$PCName)
    $record = [PSCustomObject]@{
        Username  = $Username
        PCName    = $PCName
        Timestamp = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        Domain    = $env:USERDOMAIN
        IPAddress = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.IPAddress -notlike '127.*'} | Select-Object -First 1 -ExpandProperty IPAddress)
    }
    # Thread-safe file write with retry
    $maxRetry = 5; $attempt = 0
    while ($attempt -lt $maxRetry) {
        try {
            if (Test-Path $LogCSV) {
                $record | Export-Csv $LogCSV -Append -NoTypeInformation -ErrorAction Stop
            } else {
                $record | Export-Csv $LogCSV -NoTypeInformation -ErrorAction Stop
            }
            break
        } catch {
            $attempt++
            Start-Sleep -Milliseconds (200 * $attempt)
        }
    }
    if ($attempt -eq $maxRetry) {
        Write-PolicyLog "WARNING: Could not write to network CSV after $maxRetry attempts." "Warning"
    }
}

# ─── MONITOR: Detect & manage dual monitors ───────────────────────────────────
function Get-MonitorCount {
    Add-Type -AssemblyName System.Windows.Forms
    return [System.Windows.Forms.Screen]::AllScreens.Count
}

function Disable-SecondaryMonitors {
    <#
    Uses DisplaySwitch.exe to set primary-only mode, effectively blacking out
    secondary monitors. Saves current config to registry for restore.
    #>
    $monitorCount = Get-MonitorCount
    if ($monitorCount -gt 1) {
        Write-PolicyLog "Dual monitors detected ($monitorCount). Disabling secondary during policy acceptance."
        # Save flag so restore knows monitors were active
        Set-ItemProperty -Path "HKCU:\Software\CBCPolicy" -Name "HadMultiMonitor" -Value 1 -ErrorAction SilentlyContinue
        # Switch to primary display only (blacks out secondary)
        Start-Process "DisplaySwitch.exe" -ArgumentList "/internal" -Wait
        Start-Sleep -Seconds 2
        return $true
    }
    return $false
}

function Enable-AllMonitors {
    <#
    Restores extended desktop mode after policy acceptance.
    #>
    $hadMulti = $false
    try {
        $hadMulti = (Get-ItemProperty -Path "HKCU:\Software\CBCPolicy" -Name "HadMultiMonitor" -ErrorAction SilentlyContinue).HadMultiMonitor -eq 1
    } catch {}

    if ($hadMulti) {
        Write-PolicyLog "Restoring dual monitor (extended) mode."
        Start-Process "DisplaySwitch.exe" -ArgumentList "/extend" -Wait
        Start-Sleep -Seconds 2
        # Clear the flag
        Remove-ItemProperty -Path "HKCU:\Software\CBCPolicy" -Name "HadMultiMonitor" -ErrorAction SilentlyContinue
    }
}

# ─── KIOSK LOCK: Disable task manager, alt-tab, win keys ─────────────────────
function Enable-KioskLock {
    Write-PolicyLog "Enabling kiosk restrictions."
    $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System"
    if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }
    Set-ItemProperty -Path $regPath -Name "DisableTaskMgr" -Value 1

    # Disable explorer (prevents taskbar/start menu interaction)
    # We use a kiosk shell approach via a temp scheduled task instead
    # Block Win key via registry
    $explorerPolicy = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    if (-not (Test-Path $explorerPolicy)) { New-Item -Path $explorerPolicy -Force | Out-Null }
    Set-ItemProperty -Path $explorerPolicy -Name "NoWinKeys" -Value 1

    # Disable alt-tab / alt-f4 via keyboard hook (handled in Python viewer)
}

function Disable-KioskLock {
    Write-PolicyLog "Removing kiosk restrictions."
    $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System"
    if (Test-Path $regPath) {
        Remove-ItemProperty -Path $regPath -Name "DisableTaskMgr" -ErrorAction SilentlyContinue
    }
    $explorerPolicy = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    if (Test-Path $explorerPolicy) {
        Remove-ItemProperty -Path $explorerPolicy -Name "NoWinKeys" -ErrorAction SilentlyContinue
    }
}

# ─── ENSURE REGISTRY KEY EXISTS ───────────────────────────────────────────────
$regRoot = "HKCU:\Software\CBCPolicy"
if (-not (Test-Path $regRoot)) { New-Item -Path $regRoot -Force | Out-Null }

# ─── MAIN FLOW ────────────────────────────────────────────────────────────────
Write-PolicyLog "PolicyLogon.ps1 started for user '$env:USERNAME' on '$env:COMPUTERNAME'."

# 1. Skip if already accepted
if (Test-AlreadyAccepted) { exit 0 }

# 2. Validate required files
if (-not (Test-Path $PolicyPDF)) {
    Write-PolicyLog "ERROR: Policy PDF not found at '$PolicyPDF'" "Error"
    exit 1
}
if (-not (Test-Path $ViewerScript)) {
    Write-PolicyLog "ERROR: PolicyViewer.py not found at '$ViewerScript'" "Error"
    exit 1
}

# 3. Check Python is available
try {
    $pyVersion = & $PythonExe --version 2>&1
    Write-PolicyLog "Python found: $pyVersion"
} catch {
    Write-PolicyLog "ERROR: Python not found. Install Python 3.8+ and ensure it is in PATH." "Error"
    [System.Windows.Forms.MessageBox]::Show(
        "Python is required for the policy viewer but was not found.`nContact IT Support.",
        "CBC Policy Viewer - Error", "OK", "Error")
    exit 1
}

# 4. Install required Python packages silently if missing
Write-PolicyLog "Ensuring Python dependencies are installed."
& $PythonExe -m pip install --quiet --upgrade PyMuPDF Pillow 2>&1 | Out-Null

# 5. Disable secondary monitors (if dual monitor setup)
$hadDualMonitor = Disable-SecondaryMonitors

# 6. Enable kiosk lock
Enable-KioskLock

# 7. Launch Python kiosk viewer and wait
Write-PolicyLog "Launching policy kiosk viewer."
$tempAcceptFile = "$env:TEMP\cbc_policy_accepted_$($env:USERNAME).tmp"
if (Test-Path $tempAcceptFile) { Remove-Item $tempAcceptFile -Force }

$viewerArgs = @(
    "`"$ViewerScript`"",
    "--pdf", "`"$PolicyPDF`"",
    "--user", "`"$env:USERNAME`"",
    "--pc", "`"$env:COMPUTERNAME`"",
    "--accept-flag", "`"$tempAcceptFile`""
)

$proc = Start-Process -FilePath $PythonExe `
    -ArgumentList $viewerArgs `
    -PassThru `
    -WindowStyle Normal

# Wait for viewer to exit
$proc.WaitForExit()
$exitCode = $proc.ExitCode
Write-PolicyLog "Viewer exited with code: $exitCode"

# 8. Disable kiosk lock
Disable-KioskLock

# 9. Check if user accepted
$accepted = (Test-Path $tempAcceptFile) -or ($exitCode -eq 0)

if ($accepted) {
    Write-PolicyLog "User '$env:USERNAME' ACCEPTED the policy."

    # Save acceptance records
    Save-LocalAcceptance -Username $env:USERNAME -PCName $env:COMPUTERNAME
    Save-NetworkAcceptance -Username $env:USERNAME -PCName $env:COMPUTERNAME

    # Clean up temp flag
    if (Test-Path $tempAcceptFile) { Remove-Item $tempAcceptFile -Force }

    # 10. Restore dual monitors
    if ($hadDualMonitor) { Enable-AllMonitors }

    Write-PolicyLog "Logon script completed successfully."
} else {
    Write-PolicyLog "User '$env:USERNAME' DID NOT accept the policy. Logging off." "Warning"

    # Restore monitors before logoff so display is clean
    if ($hadDualMonitor) { Enable-AllMonitors }

    # Force logoff — user must accept to use the PC
    Start-Sleep -Seconds 3
    logoff
}

exit 0
