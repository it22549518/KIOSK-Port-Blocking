#Requires -Version 5.1
<#
.SYNOPSIS
    CBC Policy Acceptance Report Tool
.DESCRIPTION
    View, export, and manage the policy acceptance log CSV.
    Run this manually by IT admins — NOT part of GPO.

USAGE:
    .\PolicyReport.ps1                    # Show summary table
    .\PolicyReport.ps1 -Export            # Export to HTML report
    .\PolicyReport.ps1 -Reset "jdoe"      # Remove a user (force re-read)
    .\PolicyReport.ps1 -ResetAll          # Clear all records (new policy rollout)
#>

param(
    [switch]$Export,
    [string]$Reset    = "",
    [switch]$ResetAll
)

$ScriptRoot = $PSScriptRoot
$LogCSV     = Join-Path $ScriptRoot "accepted_users.csv"

if (-not (Test-Path $LogCSV)) {
    Write-Host "No acceptance log found at: $LogCSV" -ForegroundColor Yellow
    exit 0
}

$records = Import-Csv $LogCSV

# ─── RESET A USER ─────────────────────────────────────────────────────────────
if ($Reset -ne "") {
    $filtered = $records | Where-Object { $_.Username -ne $Reset }
    $filtered | Export-Csv $LogCSV -NoTypeInformation
    Write-Host "Removed user '$Reset' from acceptance log. They will see the kiosk on next logon." -ForegroundColor Cyan
    exit 0
}

if ($ResetAll) {
    $confirm = Read-Host "Are you sure you want to CLEAR ALL acceptance records? (yes/no)"
    if ($confirm -eq "yes") {
        Remove-Item $LogCSV -Force
        Write-Host "All acceptance records cleared." -ForegroundColor Yellow
    }
    exit 0
}

# ─── DISPLAY SUMMARY ─────────────────────────────────────────────────────────
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "   Commercial Bank of Ceylon – Policy Acceptance Report" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  Total accepted: $($records.Count)" -ForegroundColor Green
Write-Host "  Log file: $LogCSV"
Write-Host ""
$records | Sort-Object Timestamp -Descending | Format-Table Username, PCName, Domain, IPAddress, Timestamp -AutoSize

# ─── HTML EXPORT ─────────────────────────────────────────────────────────────
if ($Export) {
    $reportPath = Join-Path $ScriptRoot "PolicyAcceptanceReport_$(Get-Date -Format 'yyyyMMdd_HHmm').html"
    $rows = $records | Sort-Object Timestamp -Descending | ForEach-Object {
        "<tr><td>$($_.Username)</td><td>$($_.PCName)</td><td>$($_.Domain)</td><td>$($_.IPAddress)</td><td>$($_.Timestamp)</td></tr>"
    }
    $html = @"
<!DOCTYPE html><html><head>
<title>CBC Policy Acceptance Report</title>
<style>
  body{font-family:Segoe UI,sans-serif;background:#0a1628;color:#e8e8e8;padding:30px}
  h1{color:#c8960c;border-bottom:2px solid #c8960c;padding-bottom:10px}
  table{width:100%;border-collapse:collapse;margin-top:20px}
  th{background:#1a2e4a;color:#c8960c;padding:10px;text-align:left}
  td{padding:9px;border-bottom:1px solid #1a2e4a}
  tr:hover td{background:#1a2e4a}
  .stat{color:#4cde7a;font-size:1.2em}
</style></head><body>
<h1>🏛 Commercial Bank of Ceylon – Policy Acceptance Report</h1>
<p>Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') &nbsp;|&nbsp; <span class="stat">Total accepted: $($records.Count)</span></p>
<table><tr><th>Username</th><th>PC Name</th><th>Domain</th><th>IP Address</th><th>Timestamp</th></tr>
$($rows -join "`n")
</table></body></html>
"@
    $html | Out-File $reportPath -Encoding UTF8
    Write-Host "HTML report saved: $reportPath" -ForegroundColor Green
    Start-Process $reportPath
}
