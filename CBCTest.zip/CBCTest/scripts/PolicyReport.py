#!/usr/bin/env python3
"""
CBC Policy Acceptance – Admin Report Tool
Usage:
    python PolicyReport.py                   # print table to terminal
    python PolicyReport.py --export html     # open HTML report in browser
    python PolicyReport.py --export csv      # export CSV
    python PolicyReport.py --reset jdoe      # remove user (force re-read)
    python PolicyReport.py --reset-all       # clear all (new policy version)
    python PolicyReport.py --stats           # show summary statistics
"""
import sys, os, argparse, sqlite3, datetime, webbrowser, csv

DB_DEFAULT = os.path.join(os.path.dirname(__file__), "policy_log.db")

def connect(db_path):
    if not os.path.exists(db_path):
        print(f"ERROR: DB not found: {db_path}")
        sys.exit(1)
    return sqlite3.connect(db_path, timeout=10)

def fetch_all(db_path):
    with connect(db_path) as con:
        con.row_factory = sqlite3.Row
        return con.execute(
            "SELECT * FROM policy_acceptance ORDER BY end_time DESC"
        ).fetchall()

def print_table(rows):
    if not rows:
        print("No records found.")
        return
    print(f"\n{'ID':<5} {'Username':<20} {'PC Name':<18} {'Domain':<12} "
          f"{'IP Address':<16} {'Start Time':<22} {'End Time':<22} "
          f"{'Duration':>10}  {'Version'}")
    print("─" * 130)
    for r in rows:
        dur = f"{r['read_duration_sec']//60}m {r['read_duration_sec']%60}s"
        print(f"{r['id']:<5} {r['username']:<20} {r['pc_name']:<18} "
              f"{(r['domain'] or ''):<12} {(r['ip_address'] or ''):<16} "
              f"{r['start_time']:<22} {r['end_time']:<22} {dur:>10}  {r['policy_version']}")
    print(f"\nTotal records: {len(rows)}\n")

def export_html(rows, db_path):
    out = os.path.join(os.path.dirname(db_path),
                       f"PolicyReport_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.html")
    tr_rows = ""
    for r in rows:
        dur = f"{r['read_duration_sec']//60}m {r['read_duration_sec']%60}s"
        tr_rows += (f"<tr><td>{r['id']}</td><td>{r['username']}</td>"
                    f"<td>{r['pc_name']}</td><td>{r['domain'] or ''}</td>"
                    f"<td>{r['ip_address'] or ''}</td><td>{r['start_time']}</td>"
                    f"<td>{r['end_time']}</td><td>{dur}</td>"
                    f"<td>{r['policy_version']}</td></tr>\n")
    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<title>CBC Policy Acceptance Report</title>
<style>
  body{{font-family:Segoe UI,sans-serif;background:#0a1628;color:#e8e8e8;padding:30px;margin:0}}
  h1{{color:#c8960c;border-bottom:2px solid #c8960c;padding-bottom:12px}}
  .stat{{color:#4cde7a;font-weight:bold;font-size:1.1em}}
  table{{width:100%;border-collapse:collapse;margin-top:20px;font-size:0.9em}}
  th{{background:#1a2e4a;color:#c8960c;padding:10px 12px;text-align:left;position:sticky;top:0}}
  td{{padding:9px 12px;border-bottom:1px solid #1a2e4a;white-space:nowrap}}
  tr:hover td{{background:#1a2e4a}}
  .footer{{color:#445566;font-size:0.8em;margin-top:20px}}
</style></head><body>
<h1>🏛 Commercial Bank of Ceylon – Policy Acceptance Report</h1>
<p>Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} &nbsp;|&nbsp;
   <span class="stat">Total records: {len(rows)}</span></p>
<table>
<tr><th>ID</th><th>Username</th><th>PC Name</th><th>Domain</th>
    <th>IP Address</th><th>Start Time</th><th>End Time</th>
    <th>Read Duration</th><th>Policy Version</th></tr>
{tr_rows}
</table>
<p class="footer">Commercial Bank of Ceylon PLC – IT Operations – Network &amp; Infra Security</p>
</body></html>"""
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"HTML report saved: {out}")
    webbrowser.open(out)

def export_csv_file(rows, db_path):
    out = os.path.join(os.path.dirname(db_path),
                       f"PolicyReport_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.csv")
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["ID","Username","PC Name","Domain","IP Address",
                    "Start Time","End Time","Read Duration (sec)","Policy Version"])
        for r in rows:
            w.writerow([r["id"],r["username"],r["pc_name"],r["domain"],
                        r["ip_address"],r["start_time"],r["end_time"],
                        r["read_duration_sec"],r["policy_version"]])
    print(f"CSV exported: {out}")

def show_stats(rows):
    if not rows:
        print("No records."); return
    durations = [r["read_duration_sec"] for r in rows]
    avg = sum(durations) / len(durations)
    print(f"\n{'═'*50}")
    print(f"  CBC Policy Acceptance Statistics")
    print(f"{'═'*50}")
    print(f"  Total accepted      : {len(rows)}")
    print(f"  Average read time   : {int(avg)//60}m {int(avg)%60}s")
    print(f"  Fastest read time   : {min(durations)//60}m {min(durations)%60}s")
    print(f"  Slowest read time   : {max(durations)//60}m {max(durations)%60}s")
    # Unique users
    users = set(r["username"] for r in rows)
    pcs   = set(r["pc_name"]  for r in rows)
    print(f"  Unique users        : {len(users)}")
    print(f"  Unique PCs          : {len(pcs)}")
    versions = {}
    for r in rows:
        versions[r["policy_version"]] = versions.get(r["policy_version"], 0) + 1
    print(f"  By policy version   :")
    for v, c in versions.items():
        print(f"      {v:10s} → {c} records")
    print(f"{'═'*50}\n")

def reset_user(db_path, username):
    with connect(db_path) as con:
        cur = con.execute("DELETE FROM policy_acceptance WHERE username=?", (username,))
        con.commit()
        print(f"Removed {cur.rowcount} record(s) for user '{username}'. "
              f"They will see the kiosk on next logon.")

def reset_all(db_path):
    confirm = input("Type YES to clear ALL acceptance records: ")
    if confirm.strip() == "YES":
        with connect(db_path) as con:
            con.execute("DELETE FROM policy_acceptance")
            con.commit()
        print("All records cleared.")
    else:
        print("Cancelled.")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db",        default=DB_DEFAULT)
    ap.add_argument("--export",    choices=["html","csv"], help="Export format")
    ap.add_argument("--reset",     metavar="USERNAME",     help="Remove a user's record")
    ap.add_argument("--reset-all", action="store_true",    help="Clear all records")
    ap.add_argument("--stats",     action="store_true",    help="Show statistics")
    args = ap.parse_args()

    if args.reset:
        reset_user(args.db, args.reset); return
    if args.reset_all:
        reset_all(args.db); return

    rows = fetch_all(args.db)

    if args.stats:
        show_stats(rows); return

    print_table(rows)

    if args.export == "html":
        export_html(rows, args.db)
    elif args.export == "csv":
        export_csv_file(rows, args.db)

if __name__ == "__main__":
    main()
