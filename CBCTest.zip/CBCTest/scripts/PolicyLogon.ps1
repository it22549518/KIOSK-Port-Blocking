#Requires -Version 5.1
<#
.SYNOPSIS
    CBC Policy Acceptance Kiosk – GPO Logon Script v3
    Commercial Bank of Ceylon PLC – IT Operations

.DESCRIPTION
    Runs at every user logon via GPO.
    1. Checks SQLite DB – if user already accepted on this PC → skips
    2. On dual monitors → blacks out secondary until acceptance
    3. Locks kiosk (disables Task Manager, Win key)
    4. Launches PolicyViewer.py (image-based, no PDF needed)
    5. On accept → DB already written by Python; restores monitors
    6. On reject / close → force logoff

FOLDER STRUCTURE ON SHARE (e.g. \\CBC-DC01\PolicyKiosk\):
    PolicyLogon.ps1       ← this file (GPO calls this)
    PolicyViewer.py       ← Python kiosk viewer
    policy_log.db         ← SQLite DB (auto-created)
    images\
        1.png … 16.png    ← your 16 screenshot images
#>

# ══════════════════════════════════════════════════════════
#  CONFIGURATION  – edit these paths to match your share
# ══════════════════════════════════════════════════════════
$ShareRoot     = "\\CBC-DC01\PolicyKiosk"          # UNC path to your share
$ImagesDir     = "$ShareRoot\images"               # folder with 1.png–16.png
$ViewerScript  = "$ShareRoot\PolicyViewer.py"      # Python viewer
$NetworkDB     = "$ShareRoot\policy_log.db"        # shared SQLite DB
$LocalDB       = "$env:LOCALAPPDATA\CBCPolicy\policy_log.db"  # local cache DB
$AcceptFlag    = "$env:TEMP\cbc_accepted_$env:USERNAME.tmp"
$PolicyVersion = "v1.0"                            # bump this to force re-read
$PythonExe     = "python"                          # or full path to python.exe
# ══════════════════════════════════════════════════════════

function Write-KioskLog {
    param([string]$Msg, [string]$Lvl = "Information")
    try {
        if (-not [System.Diagnostics.EventLog]::SourceExists("CBCPolicyKiosk")) {
            New-EventLog -LogName Application -Source "CBCPolicyKiosk" -EA SilentlyContinue
        }
        Write-EventLog -LogName Application -Source "CBCPolicyKiosk" `
            -EventId 1001 -EntryType $Lvl -Message $Msg -EA SilentlyContinue
    } catch {}
    Write-Host "[$Lvl] $Msg"
}

# ── Check DB: has this user already accepted on this PC? ──────────────────────
function Test-AlreadyAccepted {
    $u = $env:USERNAME; $pc = $env:COMPUTERNAME

    foreach ($dbPath in @($LocalDB, $NetworkDB)) {
        if (-not (Test-Path $dbPath)) { continue }
        try {
            # Use Python to query SQLite (no extra PS module needed)
            $query = "SELECT COUNT(*) FROM policy_acceptance WHERE username='$u' AND pc_name='$pc' AND accepted=1 AND policy_version='$PolicyVersion';"
            $result = & $PythonExe -c "
import sqlite3, sys
try:
    con = sqlite3.connect(r'$dbPath', timeout=5)
    row = con.execute(\"$query\").fetchone()
    print(row[0] if row else 0)
    con.close()
except Exception as e:
    print(0)
" 2>$null
            if ([int]($result -replace '\D','0') -gt 0) {
                Write-KioskLog "User '$u' already accepted policy '$PolicyVersion' on '$pc'. Skipping."
                return $true
            }
        } catch {}
    }
    return $false
}

# ── Monitor management ────────────────────────────────────────────────────────
function Get-MonitorCount {
    Add-Type -AssemblyName System.Windows.Forms -EA SilentlyContinue
    return [System.Windows.Forms.Screen]::AllScreens.Count
}

function Disable-SecondaryMonitors {
    $count = Get-MonitorCount
    if ($count -gt 1) {
        Write-KioskLog "Dual monitors detected ($count). Switching to primary only."
        $regKey = "HKCU:\Software\CBCPolicy"
        if (-not (Test-Path $regKey)) { New-Item $regKey -Force | Out-Null }
        Set-ItemProperty $regKey -Name "HadMultiMonitor" -Value 1
        Start-Process "DisplaySwitch.exe" -ArgumentList "/internal" -Wait
        Start-Sleep -Seconds 2
        return $true
    }
    return $false
}

function Enable-AllMonitors {
    $regKey = "HKCU:\Software\CBCPolicy"
    $had = $false
    try { $had = (Get-ItemProperty $regKey -Name "HadMultiMonitor" -EA Stop).HadMultiMonitor -eq 1 } catch {}
    if ($had) {
        Write-KioskLog "Restoring extended desktop (dual monitor)."
        Start-Process "DisplaySwitch.exe" -ArgumentList "/extend" -Wait
        Start-Sleep -Seconds 2
        Remove-ItemProperty $regKey -Name "HadMultiMonitor" -EA SilentlyContinue
    }
}

# ── Kiosk lock / unlock ───────────────────────────────────────────────────────
function Set-KioskLock ([bool]$Enable) {
    $sys = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System"
    $exp = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    if ($Enable) {
        foreach ($p in @($sys,$exp)) { if (-not (Test-Path $p)) { New-Item $p -Force | Out-Null } }
        Set-ItemProperty $sys -Name "DisableTaskMgr" -Value 1
        Set-ItemProperty $exp -Name "NoWinKeys"      -Value 1
        Write-KioskLog "Kiosk lock ENABLED."
    } else {
        Remove-ItemProperty $sys -Name "DisableTaskMgr" -EA SilentlyContinue
        Remove-ItemProperty $exp -Name "NoWinKeys"      -EA SilentlyContinue
        Write-KioskLog "Kiosk lock DISABLED."
    }
}

# ══════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════
Write-KioskLog "PolicyLogon.ps1 started | User: $env:USERNAME | PC: $env:COMPUTERNAME"

# Ensure reg key exists
$rk = "HKCU:\Software\CBCPolicy"
if (-not (Test-Path $rk)) { New-Item $rk -Force | Out-Null }

# 1. Skip if already accepted
if (Test-AlreadyAccepted) { exit 0 }

# 2. Validate files exist
foreach ($f in @($ViewerScript, $ImagesDir)) {
    if (-not (Test-Path $f)) {
        Write-KioskLog "ERROR: Required path missing: $f" "Error"
        exit 1
    }
}

# 3. Ensure Pillow installed
Write-KioskLog "Checking Python dependencies..."
& $PythonExe -m pip install --quiet Pillow 2>&1 | Out-Null

# 4. Dual monitor – disable secondary
$hadDual = Disable-SecondaryMonitors

# 5. Lock kiosk
Set-KioskLock $true

# 6. Clean old flag file
if (Test-Path $AcceptFlag) { Remove-Item $AcceptFlag -Force }

# 7. Launch Python viewer
Write-KioskLog "Launching PolicyViewer..."
$args = @(
    "`"$ViewerScript`"",
    "--images-dir", "`"$ImagesDir`"",
    "--db",         "`"$NetworkDB`"",
    "--user",       "`"$env:USERNAME`"",
    "--pc",         "`"$env:COMPUTERNAME`"",
    "--domain",     "`"$env:USERDOMAIN`"",
    "--accept-flag","`"$AcceptFlag`"",
    "--policy-version", "`"$PolicyVersion`""
)
$proc = Start-Process -FilePath $PythonExe -ArgumentList $args -PassThru -WindowStyle Normal
$proc.WaitForExit()
Write-KioskLog "Viewer exited. Code: $($proc.ExitCode)"

# 8. Unlock
Set-KioskLock $false

# 9. Check acceptance
$accepted = (Test-Path $AcceptFlag) -or ($proc.ExitCode -eq 0)

if ($accepted) {
    Write-KioskLog "ACCEPTED by $env:USERNAME on $env:COMPUTERNAME."
    if (Test-Path $AcceptFlag) { Remove-Item $AcceptFlag -Force }

    # Copy DB locally for offline check next logon
    try {
        $localDir = Split-Path $LocalDB
        if (-not (Test-Path $localDir)) { New-Item $localDir -ItemType Directory -Force | Out-Null }
        Copy-Item $NetworkDB $LocalDB -Force -EA SilentlyContinue
    } catch {}

    # Restore monitors
    if ($hadDual) { Enable-AllMonitors }

    Write-KioskLog "Logon complete."
    exit 0
} else {
    Write-KioskLog "NOT accepted. Logging off user." "Warning"
    if ($hadDual) { Enable-AllMonitors }
    Start-Sleep -Seconds 2
    logoff
}
