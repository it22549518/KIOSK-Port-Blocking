# CBC Policy Kiosk v3 – Complete Deployment Guide
**Commercial Bank of Ceylon PLC – IT Operations – Network & Infra Security**

---

## What's in This Package

```
PolicyKiosk_v3\
├── scripts\
│   ├── PolicyLogon.ps1     ← GPO logon script (entry point)
│   ├── PolicyViewer.py     ← Python kiosk (image-based, no PDF needed)
│   └── PolicyReport.py     ← Admin reporting tool
├── images\                 ← YOU CREATE THIS — put 1.png to 16.png here
└── README.md               ← this file
```

---

## STEP 1 — Prepare Your 16 Screenshots

Take screenshots of your policy document pages and save them as:
```
1.png   2.png   3.png   ...   16.png
```
- Format: PNG or JPG (PNG recommended for sharpness)
- Recommended size: 1920×1080 or higher
- Place all 16 files in the `images\` folder

---

## STEP 2 — Create the Network Share on Your AD Server

On your **Domain Controller** or **File Server**:

1. Create a folder:
```
C:\PolicyKiosk\
```

2. Copy these files into it:
```
C:\PolicyKiosk\PolicyLogon.ps1
C:\PolicyKiosk\PolicyViewer.py
C:\PolicyKiosk\PolicyReport.py
C:\PolicyKiosk\images\1.png  (… through 16.png)
```

3. Share the folder:
   - Right-click `C:\PolicyKiosk` → Properties → Sharing → Advanced Sharing
   - Share name: `PolicyKiosk`
   - Permissions: `Domain Computers` → **Read**
   - Permissions: `Domain Admins`   → **Full Control**
   - Result: `\\CBC-DC01\PolicyKiosk\`

4. Also set NTFS permissions:
   - `Domain Computers` → Read & Execute
   - `Domain Admins`    → Full Control

5. The DB file (`policy_log.db`) is auto-created when first user accepts.
   But for the DB to be writeable by all domain PCs, also give:
   - `Domain Computers` → **Modify** permission on the `PolicyKiosk` folder
     (so they can write to the .db file)

---

## STEP 3 — Edit PolicyLogon.ps1

Open `PolicyLogon.ps1` and update the top configuration block:

```powershell
$ShareRoot     = "\\CBC-DC01\PolicyKiosk"    # ← change CBC-DC01 to your server name
$PolicyVersion = "v1.0"                       # ← bump to "v2.0" when policy updates
$PythonExe     = "python"                     # ← or full path if Python not in PATH
```

---

## STEP 4 — Install Python on All PCs

**Option A — Manual install (testing):**
```
1. Download Python 3.10+ from python.org
2. Install with "Add Python to PATH" checked
3. Verify: open CMD → python --version
```

**Option B — Deploy via SCCM/Intune (production):**
- Use a silent installer:
```cmd
python-3.13.0-amd64.exe /quiet InstallAllUsers=1 PrependPath=1
```

**Option C — No Python install (easiest for production):**
Bundle the viewer as a standalone EXE using PyInstaller:
```cmd
pip install pyinstaller
pyinstaller --onefile --noconsole --name PolicyViewer PolicyViewer.py
```
Place `PolicyViewer.exe` in the share folder.
In `PolicyLogon.ps1`, change:
```powershell
$PythonExe = ""
# Replace the Start-Process line with:
$proc = Start-Process "$ShareRoot\PolicyViewer.exe" -ArgumentList $args -PassThru
```

---

## STEP 5 — Configure the GPO

On your Domain Controller:

1. Open **Group Policy Management** (`gpmc.msc`)
2. Right-click the **OU** containing your employee computers → **Create a GPO**
3. Name it: `CBC Policy Kiosk`
4. Right-click the new GPO → **Edit**

### Add the logon script:
```
User Configuration
  → Windows Settings
    → Scripts (Logon/Logoff)
      → Logon → Add
        Script Name: \\CBC-DC01\PolicyKiosk\PolicyLogon.ps1
```

### Allow PowerShell scripts to run:
```
Computer Configuration
  → Administrative Templates
    → Windows Components
      → Windows PowerShell
        → Turn on Script Execution → Enabled
          → Allow local scripts and remote signed scripts
```

### Optional — Hide taskbar during logon (extra security):
```
User Configuration
  → Administrative Templates
    → Start Menu and Taskbar
      → "Remove Taskbar and Start Menu" → Enabled
```
(The Python viewer handles this, but GPO is belt-and-suspenders)

5. Close GPO editor → Link GPO to the correct OU

---

## STEP 6 — Test on Your Local PC First

```cmd
cd \\CBC-DC01\PolicyKiosk

python PolicyViewer.py ^
  --images-dir "\\CBC-DC01\PolicyKiosk\images" ^
  --db "\\CBC-DC01\PolicyKiosk\policy_log.db" ^
  --user "TestUser" ^
  --pc "TestPC" ^
  --domain "CBC" ^
  --accept-flag "C:\Temp\test_accepted.tmp"
```

**Expected behaviour:**
- ✅ Full screen opens, page 1 of 16 shown
- ✅ Next/Previous buttons work, mouse wheel scrolls
- ✅ Timer counting up in top-right corner
- ✅ Accept button appears ONLY on page 16
- ✅ After clicking Accept → thank-you screen shows read time + IP
- ✅ Record saved to `policy_log.db`

---

## STEP 7 — View Acceptance Reports

Run from the share folder or copy `PolicyReport.py` to your admin PC:

```cmd
# Print table in terminal
python PolicyReport.py --db "\\CBC-DC01\PolicyKiosk\policy_log.db"

# Open HTML report in browser
python PolicyReport.py --db "\\CBC-DC01\PolicyKiosk\policy_log.db" --export html

# Export CSV (for Excel)
python PolicyReport.py --db "\\CBC-DC01\PolicyKiosk\policy_log.db" --export csv

# Show statistics (avg read time, fastest, slowest, total users)
python PolicyReport.py --db "\\CBC-DC01\PolicyKiosk\policy_log.db" --stats

# Force one user to re-read (e.g. they were absent during rollout)
python PolicyReport.py --db "\\CBC-DC01\PolicyKiosk\policy_log.db" --reset jdoe

# New policy version — reset everyone (update PolicyVersion in PS1 first!)
python PolicyReport.py --db "\\CBC-DC01\PolicyKiosk\policy_log.db" --reset-all
```

---

## Database Schema

The DB saves these fields per acceptance:

| Column | Example | Notes |
|---|---|---|
| username | jdoe | AD username |
| pc_name | BRANCH-PC-042 | Computer name |
| domain | CBC | AD domain |
| ip_address | 192.168.1.45 | PC's IP at time of reading |
| start_time | 2026-06-08 08:32:11 | When kiosk opened |
| end_time | 2026-06-08 08:47:53 | When Accept clicked |
| read_duration_sec | 942 | = 15m 42s |
| policy_version | v1.0 | Matches script config |
| accepted | 1 | Always 1 (non-accepted = no record) |

---

## Dual Monitor Behaviour

| Situation | Behaviour |
|---|---|
| Single monitor PC | Normal full-screen kiosk |
| Dual monitor, not yet accepted | Secondary blacks out; kiosk on primary |
| User clicks Accept | Both monitors restored automatically |
| User already accepted (any logon) | Both monitors work normally from start |

---

## When You Update the Policy (New Policy Version)

1. Replace `1.png – 16.png` in the images folder
2. In `PolicyLogon.ps1`, change:
```powershell
$PolicyVersion = "v2.0"    # was "v1.0"
```
3. All users will see the kiosk again on next logon (old v1.0 records are kept, new v2.0 required)

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Script cannot be loaded" on logon | Set PowerShell execution policy in GPO (Step 5) |
| Python not found | Install Python with PATH, or use .exe bundle (Option C) |
| Images not loading | Check 1.png–16.png exist in `images\` folder, check share permissions |
| DB not writing | Give Domain Computers **Modify** on share folder (Step 2) |
| Kiosk doesn't appear | Run `gpupdate /force` on test PC, check GPO is linked to correct OU |
| Dual monitor not restoring | Run `DisplaySwitch.exe /extend` manually to test |
| User already accepted but kiosk shows again | Check `$PolicyVersion` is same in both logons |

---

**IT Operations – Network & Infra Security**
**Commercial Bank of Ceylon PLC**
